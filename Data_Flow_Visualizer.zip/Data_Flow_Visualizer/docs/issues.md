# 🧠 Issues

- [x] Initial setup
- [x] Edge filtering by type
- [x] Color mapping
