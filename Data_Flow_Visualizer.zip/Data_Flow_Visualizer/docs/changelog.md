# 📦 Changelog

## v1.0
- Initial working version
