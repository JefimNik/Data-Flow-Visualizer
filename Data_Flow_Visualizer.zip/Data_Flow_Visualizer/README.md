# Data Flow Visualizer

Полностью готовый пайплайн для визуализации потоков данных.
Запуск: pip install -r requirements.txt → python run_pipeline.py
